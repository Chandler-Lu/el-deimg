# el-deimg
Decode disk image used by Yamaha Electone

Ugly and dircty solution to extract files from Electone Disk.
Code is old and not clean.

For HDCOPY image structure, checkout [this blog post(in Chinese)](http://techlog.sinaapp.com/?p=24)
